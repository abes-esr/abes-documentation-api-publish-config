import logging
import re
from enum import Enum
from typing import Any

import requests
from requests import HTTPError


class StrEnum(str, Enum):
    pass

    def __str__(self):
        return str(self.value)


class StrBooleanEnum(StrEnum):
    true = "true"
    false = "false"


class IntEnum(Enum):
    pass

    def __int__(self):
        return int(self.value)


def serialize_cdm(obj):
    """Cdm Serializer"""
    cdm = ""
    if issubclass(type(obj), dict):
        cdm += "("
        first = True
        for key in obj:
            if re.match(".*[^0-z].*", key):
                cdm += "'" if first else  ".'"
                cdm += key.replace("'", "''")
                cdm += "'."
            else:
                cdm += key
            cdm += serialize_cdm(obj[key])
            if first:
                first = False
        cdm += ")"
    elif type(obj) is str:
        cdm += "'%s'" % obj.replace("'", "''")
    elif issubclass(type(obj), StrEnum):
        cdm += "'%s'" % obj.value.replace("'", "''")
    elif type(obj) is bool:
        cdm += "!T!" if obj else "!F!"
    elif issubclass(type(obj), list):
        cdm += "*"
        for idx, val in enumerate(obj):
            cdm += serialize_cdm(val)
            if idx < len(obj)-1:
                cdm += "."
        cdm += "-"
    elif obj is None:
        cdm += '!!'
    elif issubclass(type(obj), IntEnum):
        cdm += "!%d!" % obj
    else:
        cdm += "!%d!" % obj
    return cdm


def text(response: requests.Response) -> str:
    try:
        return response.content.decode("utf-8")
    except AttributeError:
        logging.error(f"Unable to extract text from response argument {response}")
    except ValueError:
        txt = response.text
        status = response.status_code
        logging.error(f"Unable to extract JSON from HTTP response [code:{status}].\n{txt}")
    raise RuntimeError(f"Unable to extract JSON data from {response.text}")


def json(response: requests.Response) -> Any:
    try:
        return response.json()
    except AttributeError:
        logging.error("Unable to extract JSON from response argument %s" % response)
    except ValueError:
        txt = text(response)
        status = response.status_code
        logging.error("Unable to extract JSON from HTTP response [code:%d].\n%s" % (status, txt))
    raise RuntimeError("Unable to extract JSON data from %s" % text(response))


def check_status(response:requests.Response, *status:int)->Any:
    try:
        if response.status_code not in status:
            raise HTTPError("Wrong HTTP Response. Should be in  %s, got %d" % (status, response.status_code), response=response)
        else:
            return
    except AttributeError:
        logging.error("Unable to extract status code from response argument %s" % response)
    raise RuntimeError("HTTP status control failed from response %s" % response)
